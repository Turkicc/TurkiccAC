package com.example.ac.violation;

import com.example.ac.check.Check;
import com.example.ac.config.ACConfig;
import com.example.ac.data.PlayerData;
import com.example.ac.util.SchedulerUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Central accounting for violations:
 *   - {@link #flag} adds weighted VL (capped at the check's max), writes a log
 *     line, sends throttled staff alerts, and runs the matching punishment tier.
 *   - {@link #decayTick} is called on a fixed schedule to bleed VL down so a
 *     clean player eventually returns to zero.
 *
 * A single anomalous tick can never ban: punishments are gated behind VL
 * thresholds, and KICK/BAN are guarded so they don't re-fire in a burst.
 */
public final class ViolationManager {

    private final JavaPlugin plugin;
    private final ACConfig config;

    /** Throttle: "uuid:check" -> last alert time (ms). */
    private final ConcurrentHashMap<String, Long> alertGuard = new ConcurrentHashMap<>();
    /** Guard so KICK/BAN don't spam: "uuid:check:action" -> last fire time (ms). */
    private final ConcurrentHashMap<String, Long> punishGuard = new ConcurrentHashMap<>();
    /** Staff who have toggled their own alerts off via /sentinel alerts. */
    private final java.util.Set<java.util.UUID> mutedAlerts =
            java.util.concurrent.ConcurrentHashMap.newKeySet();

    private final DateTimeFormatter ts = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private Path logFile;

    public ViolationManager(JavaPlugin plugin, ACConfig config) {
        this.plugin = plugin;
        this.config = config;
        if (config.fileLogging) {
            try {
                Path dir = plugin.getDataFolder().toPath();
                Files.createDirectories(dir);
                logFile = dir.resolve("sentinel.log");
            } catch (IOException e) {
                plugin.getLogger().log(Level.WARNING, "Could not open sentinel.log", e);
            }
        }
    }

    /**
     * Record a violation. Thread-safe; usually called from a Netty packet
     * thread. Bukkit-touching actions (kick/ban/alert dispatch) are scheduled
     * onto the correct thread internally.
     */
    public FlagResult flag(Check check, PlayerData data, String reason, double weight) {
        double newVl = data.addViolation(check.name(), weight, check.maxVl());

        // File log every flag.
        log(data, check.name(), reason, newVl);

        // Find the highest tier whose threshold we've crossed.
        PunishmentTier crossed = null;
        for (PunishmentTier tier : config.getTiers(check.punishmentTier())) {
            if (newVl >= tier.vl) crossed = tier; // list is ascending
        }

        boolean cancel = false;
        if (crossed != null) {
            if (crossed.has(PunishmentTier.Action.ALERT)) {
                sendAlert(data, check.name(), reason, newVl);
            }
            cancel = crossed.has(PunishmentTier.Action.CANCEL);
            if (crossed.has(PunishmentTier.Action.KICK)) {
                tryKick(data, check.name(), crossed);
            }
            if (crossed.has(PunishmentTier.Action.BAN)) {
                tryBan(data, check.name(), reason, newVl, crossed);
            }
        }
        return new FlagResult(newVl, cancel);
    }

    private void sendAlert(PlayerData data, String check, String reason, double vl) {
        long now = System.currentTimeMillis();
        String key = data.uuid + ":" + check;
        Long last = alertGuard.get(key);
        if (last != null && now - last < config.alertCooldownMs) return;
        alertGuard.put(key, now);

        String msg = config.alertFormat
                .replace("{player}", data.name)
                .replace("{check}", check)
                .replace("{reason}", reason)
                .replace("{vl}", String.format("%.1f", vl))
                .replace("{ping}", String.valueOf(data.pingMs));

        // Component/legacy message sends are safe from any thread on Paper.
        Bukkit.getConsoleSender().sendMessage(msg);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("anticheat.alerts") && !mutedAlerts.contains(p.getUniqueId())) {
                p.sendMessage(msg);
            }
        }
    }

    /** Toggle a staff member's alert visibility. @return true if now receiving. */
    public boolean toggleAlerts(java.util.UUID uuid) {
        if (mutedAlerts.remove(uuid)) return true;
        mutedAlerts.add(uuid);
        return false;
    }

    private void tryKick(PlayerData data, String check, PunishmentTier tier) {
        if (guarded(data, check, "KICK")) return;
        Player p = Bukkit.getPlayer(data.uuid);
        if (p == null) return;
        String reason = tier.kickMessage != null ? tier.kickMessage : "\u00A7cKicked by anti-cheat.";
        SchedulerUtil.runForEntity(plugin, p, () -> {
            if (p.isOnline()) p.kick(net.kyori.adventure.text.Component.text(reason));
        });
    }

    private void tryBan(PlayerData data, String check, String reason, double vl, PunishmentTier tier) {
        if (guarded(data, check, "BAN")) return;
        if (tier.banCommand == null) return;
        String cmd = tier.banCommand
                .replace("{player}", data.name)
                .replace("{check}", check)
                .replace("{reason}", reason)
                .replace("{vl}", String.format("%.1f", vl));
        // Commands must run on the main/global thread.
        SchedulerUtil.runGlobalOnce(plugin,
                () -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd));
    }

    /** True if this action fired for this player+check within the last 5s. */
    private boolean guarded(PlayerData data, String check, String action) {
        long now = System.currentTimeMillis();
        String key = data.uuid + ":" + check + ":" + action;
        Long last = punishGuard.get(key);
        if (last != null && now - last < 5000) return true;
        punishGuard.put(key, now);
        return false;
    }

    private void log(PlayerData data, String check, String reason, double vl) {
        if (logFile == null) return;
        String line = "[" + LocalDateTime.now().format(ts) + "] "
                + data.name + " (" + data.uuid + ") " + check
                + " | " + reason + " | vl=" + String.format("%.1f", vl)
                + " | ping=" + data.pingMs + "ms\n";
        try (Writer w = Files.newBufferedWriter(logFile, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            w.write(line);
        } catch (IOException ignored) {
            // never let logging failure affect gameplay
        }
    }

    /** Called every {@code violation-tick-interval} ticks to decay all VL. */
    public void decayTick(Iterable<PlayerData> players, ViolationDecayLookup lookup) {
        for (PlayerData data : players) {
            for (String checkName : data.getViolations().keySet()) {
                double decay = lookup.decayFor(checkName);
                if (decay > 0) data.decayViolation(checkName, decay);
            }
        }
    }

    /** Supplies the per-check decay rate to {@link #decayTick}. */
    public interface ViolationDecayLookup {
        double decayFor(String checkName);
    }
}
