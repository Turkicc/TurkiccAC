package com.example.ac.check.combat;

import com.example.ac.check.AttackContext;
import com.example.ac.check.Check;
import com.example.ac.config.ACConfig;
import com.example.ac.data.PlayerData;
import com.example.ac.data.PlayerDataManager;
import com.example.ac.violation.FlagResult;
import com.example.ac.violation.ViolationManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.function.LongSupplier;

/**
 * Check 6 - Mace 1-tick stun slam.
 *
 * Server ticks are too coarse to prove this by themselves. Normal client
 * packets can be batched into the same 50ms server tick, especially with ping,
 * so a legit swap can look like "0t". Packet same-tick signatures are therefore
 * optional diagnostics only. The default verdict is made from confirmed damage:
 * axe damage followed by heavy mace damage on the same target inside a tiny
 * real-time window, repeated before VL ramps.
 */
public final class MaceStunSlamCheck extends Check {

    private int maxComboTicks;
    private int maxSlamIntervalTicks;
    private int legalSwapWindowTicks;
    private long swapWindowMs;
    private boolean flagPacketSameTickSwaps;
    private int timingMaxPingMs;
    private long maxConfirmedComboMs;
    private long comboRepeatWindowMs;
    private int minConfirmedComboRepeats;
    private double minMaceDamage;
    private double weight;

    public MaceStunSlamCheck(JavaPlugin plugin, ACConfig config, PlayerDataManager dm,
                             ViolationManager vm, LongSupplier tick) {
        super("mace-stun-slam", plugin, config, dm, vm, tick);
        reloadSettings();
    }

    @Override
    protected void reloadSettings() {
        maxComboTicks = cfg != null ? cfg.getInt("max-combo-ticks", 1) : 1;
        maxSlamIntervalTicks = cfg != null ? cfg.getInt("max-slam-interval-ticks", 1) : 1;
        legalSwapWindowTicks = cfg != null ? cfg.getInt("legal-swap-window-ticks", 0) : 0;
        swapWindowMs = cfg != null ? cfg.getLong("swap-window-ms", 75) : 75;
        flagPacketSameTickSwaps = cfg != null && cfg.getBoolean("flag-packet-same-tick-swaps", false);
        timingMaxPingMs = cfg != null ? cfg.getInt("timing-max-ping-ms", 150) : 150;
        maxConfirmedComboMs = cfg != null ? cfg.getLong("max-confirmed-combo-ms", 45) : 45;
        comboRepeatWindowMs = cfg != null ? cfg.getLong("combo-repeat-window-ms", 8000) : 8000;
        minConfirmedComboRepeats = cfg != null ? cfg.getInt("min-confirmed-combo-repeats", 2) : 2;
        minMaceDamage = cfg != null ? cfg.getDouble("min-mace-damage", 8.0) : 8.0;
        weight = cfg != null ? cfg.getDouble("weight", 2.0) : 2.0;
    }

    /** Packet-time diagnostics only. Default config does not flag here. */
    public boolean handle(AttackContext ctx) {
        PlayerData a = ctx.attacker;
        long tick = ctx.tick;
        if (!enabled() || isExempt(a)) {
            updateWeaponAttackTicks(a, tick);
            return false;
        }

        boolean cancel = false;
        if (flagPacketSameTickSwaps && timingReliable(a) && a.lastSlotChangeMs != 0L) {
            long gapMs = System.currentTimeMillis() - a.lastSlotChangeMs;
            long hotbarTicks = a.lastSlotChangeTick == Long.MIN_VALUE
                    ? Long.MAX_VALUE : tick - a.lastSlotChangeTick;
            long offhandTicks = a.lastOffhandSwapTick == Long.MIN_VALUE
                    ? Long.MAX_VALUE : tick - a.lastOffhandSwapTick;
            long swapTicks = Math.min(hotbarTicks, offhandTicks);
            int tickWindow = Math.max(0, legalSwapWindowTicks);
            if (swapTicks >= 0 && swapTicks <= tickWindow && gapMs >= 0 && gapMs < swapWindowMs) {
                FlagResult r = flag(a, "packet swap+attack "
                        + swapTicks + "t/" + gapMs + "ms", weight);
                cancel |= r.cancel;
            }
        }

        updateWeaponAttackTicks(a, tick);
        return cancel;
    }

    private void updateWeaponAttackTicks(PlayerData a, long tick) {
        if (a.holdingMace) a.lastMaceAttackTick = tick;
        if (a.holdingAxe) a.lastAxeAttackTick = tick;
    }

    /**
     * Damage-confirmed check. This runs after Bukkit has applied the hit, so it
     * cannot cancel that exact packet, but it avoids the normal-swap false
     * positives caused by same-tick packet batching.
     */
    public void onDamage(PlayerData attacker, int victimEntityId,
                         double finalDamage, double attackCooldown) {
        if (!enabled() || isExempt(attacker)) return;

        long tick = now();
        long ms = System.currentTimeMillis();

        if (attacker.holdingMace) {
            if (timingReliable(attacker) && finalDamage >= minMaceDamage) {
                long axeTicks = attacker.lastAxeDamageTick == Long.MIN_VALUE
                        ? Long.MAX_VALUE : tick - attacker.lastAxeDamageTick;
                long axeMs = attacker.lastAxeDamageMs == 0L
                        ? Long.MAX_VALUE : ms - attacker.lastAxeDamageMs;
                if (attacker.lastAxeDamageEntityId == victimEntityId
                        && axeTicks >= 0 && axeTicks <= maxComboTicks
                        && axeMs >= 0 && axeMs <= maxConfirmedComboMs) {
                    confirm(attacker, "confirmed axe->mace damage combo "
                            + axeTicks + "t/" + axeMs + "ms dmg=" + fmt(finalDamage));
                }

                long maceTicks = attacker.lastMaceDamageTick == Long.MIN_VALUE
                        ? Long.MAX_VALUE : tick - attacker.lastMaceDamageTick;
                long maceMs = attacker.lastMaceDamageMs == 0L
                        ? Long.MAX_VALUE : ms - attacker.lastMaceDamageMs;
                if (attacker.lastMaceDamageEntityId == victimEntityId
                        && maceTicks >= 0 && maceTicks <= maxSlamIntervalTicks
                        && maceMs >= 0 && maceMs <= maxConfirmedComboMs) {
                    confirm(attacker, "confirmed double mace damage "
                            + maceTicks + "t/" + maceMs + "ms dmg=" + fmt(finalDamage));
                }
            }

            attacker.lastMaceDamageTick = tick;
            attacker.lastMaceDamageMs = ms;
            attacker.lastMaceDamageEntityId = victimEntityId;
            attacker.lastMaceDamage = finalDamage;
        } else if (attacker.holdingAxe) {
            attacker.lastAxeDamageTick = tick;
            attacker.lastAxeDamageMs = ms;
            attacker.lastAxeDamageEntityId = victimEntityId;
            attacker.lastAxeDamage = finalDamage;
        }
    }

    private boolean timingReliable(PlayerData attacker) {
        return timingMaxPingMs <= 0 || attacker.pingMs <= timingMaxPingMs;
    }

    private void confirm(PlayerData attacker, String reason) {
        long ms = System.currentTimeMillis();
        if (attacker.maceSuspicionWindowStartMs == 0L
                || ms - attacker.maceSuspicionWindowStartMs > comboRepeatWindowMs) {
            attacker.maceSuspicionWindowStartMs = ms;
            attacker.maceConfirmedComboRepeats = 0;
        }

        attacker.maceConfirmedComboRepeats++;
        if (attacker.maceConfirmedComboRepeats < minConfirmedComboRepeats) return;

        FlagResult r = flag(attacker, reason + " x" + attacker.maceConfirmedComboRepeats,
                weight * Math.min(3.0, attacker.maceConfirmedComboRepeats));
        if (r.cancel) {
            attacker.maceConfirmedComboRepeats = 0;
            attacker.maceSuspicionWindowStartMs = ms;
        }
    }

    private static String fmt(double value) {
        return String.format("%.1f", value);
    }
}
