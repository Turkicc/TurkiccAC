package com.example.ac.check.combat;

import com.example.ac.check.AttackContext;
import com.example.ac.check.Check;
import com.example.ac.config.ACConfig;
import com.example.ac.data.PlayerData;
import com.example.ac.data.PlayerDataManager;
import com.example.ac.data.PositionData;
import com.example.ac.util.MathUtil;
import com.example.ac.violation.FlagResult;
import com.example.ac.violation.ViolationManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.function.LongSupplier;

/**
 * Check 4 — Silent aim.
 *
 * Silent aim spoofs the rotation sent to the server so hits land on a target
 * the camera isn't pointing at. Because the server is authoritative about which
 * rotation it received, we can verify it directly: the reported look ray must
 * come within a tight cone of the (rewound) victim hitbox. If the reported
 * rotation points away from the victim yet the attack still registered on them,
 * that's silent aim.
 *
 * This ray test is stricter than the killaura {@code angle} sub-check on
 * purpose: here we expect a genuine near-hit, and we route to the high-confidence
 * {@code hard} punishment tier.
 *
 * Note on the "snap onto target for one tick then revert" variant: catching that
 * precisely needs correlating the rotation at the exact attack tick against the
 * surrounding ticks. The synchronous miss-angle test below is the high-value,
 * low-false-positive core; the {@code snap-revert-window-ticks} knob is wired
 * through for when you extend this with per-tick rotation correlation, and the
 * killaura behavioral analyzer already catches single-tick snaps statistically.
 */
public final class SilentAimCheck extends Check {

    private double hitboxExpansion;
    private double maxRayDist;
    private int minConsecutive;
    private double weight;

    public SilentAimCheck(JavaPlugin plugin, ACConfig config, PlayerDataManager dm,
                          ViolationManager vm, LongSupplier tick) {
        super("silent-aim", plugin, config, dm, vm, tick);
        reloadSettings();
    }

    @Override
    protected void reloadSettings() {
        // Generous box expansion + a couple of misses in a row keep this from
        // tripping on genuine on-target hits or a single lag-comp glitch.
        hitboxExpansion = cfg != null ? cfg.getDouble("hitbox-expansion", 0.1) : 0.3;
        maxRayDist = cfg != null ? cfg.getDouble("max-ray-dist", 8.0) : 8.0;
        minConsecutive = cfg != null ? cfg.getInt("min-consecutive", 2) : 2;
        weight = cfg != null ? cfg.getDouble("weight", 2.0) : 2.0;
    }

    /** @return true if the hit should be cancelled. */
    public boolean handle(AttackContext ctx) {
        if (!enabled() || !ctx.hasVictimHitbox()) return false;
        PlayerData attacker = ctx.attacker;
        if (isExempt(attacker)) return false;

        // Did the reported look ray actually pass through the (generously
        // expanded) victim hitbox at ANY position in the rewind window? If so,
        // the crosshair WAS on the target -> definitely not silent aim.
        boolean lookedAtTarget = false;
        for (PositionData pd : ctx.victimWindow) {
            MathUtil.AABB box = MathUtil.AABB.player(pd.x, pd.y, pd.z).expand(hitboxExpansion);
            if (MathUtil.rayIntersectAABB(ctx.eye, ctx.lookDir, box, maxRayDist) >= 0) {
                lookedAtTarget = true;
                break;
            }
        }
        if (lookedAtTarget) {
            attacker.silentAimMissStreak = 0;
            return false;
        }

        // The look ray missed the hitbox everywhere in the window, yet the hit
        // registered: the rotation used for resolution wasn't the camera's.
        // Require several misses in a row so one bad sample can't flag.
        attacker.silentAimMissStreak++;
        if (attacker.silentAimMissStreak < minConsecutive) return false;

        double bestAngle = Double.MAX_VALUE; // for the log line only
        for (PositionData pd : ctx.victimWindow) {
            MathUtil.AABB box = MathUtil.AABB.player(pd.x, pd.y, pd.z);
            bestAngle = Math.min(bestAngle, MathUtil.angleToBox(ctx.eye, ctx.lookDir, box));
        }
        FlagResult r = flag(attacker, String.format(
                "ray missed hitbox x%d (~%.0f° off)", attacker.silentAimMissStreak, bestAngle), weight);
        return r.cancel;
    }
}
