package com.example.ac;

import com.example.ac.config.ACConfig;
import com.example.ac.data.PlayerData;
import com.example.ac.data.PlayerDataManager;
import com.example.ac.listener.BukkitListener;
import com.example.ac.listener.PacketListener;
import com.example.ac.manager.CheckManager;
import com.example.ac.util.SchedulerUtil;
import com.example.ac.violation.ViolationManager;
import com.github.retrooper.packetevents.PacketEvents;
import io.github.retrooper.packetevents.factory.spigot.SpigotPacketEventsBuilder;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.LongSupplier;

/**
 * SentinelAC entry point.
 *
 * Wiring order matters: PacketEvents is built in {@link #onLoad()} (required by
 * its API) and initialised in {@link #onEnable()} after our managers exist. A
 * single monotonic tick counter is incremented once per server tick and handed
 * to every check via a {@link LongSupplier}; all check timing is expressed in
 * these ticks so the logic is independent of wall-clock scheduling.
 */
public final class AntiCheatPlugin extends JavaPlugin {

    private final AtomicLong tickCounter = new AtomicLong(0L);

    private ACConfig config;
    private PlayerDataManager dataManager;
    private ViolationManager violations;
    private CheckManager checkManager;
    private BukkitListener bukkitListener;

    @Override
    public void onLoad() {
        // PacketEvents must be created in onLoad.
        PacketEvents.setAPI(SpigotPacketEventsBuilder.build(this));
        PacketEvents.getAPI().load();
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.config = new ACConfig(this);

        int rotationSampleSize = getConfig()
                .getInt("checks.killaura.sub-checks.rotation.sample-size", 40);
        this.dataManager = new PlayerDataManager(config.historyTicks, rotationSampleSize);
        this.violations = new ViolationManager(this, config);

        final LongSupplier tickSupplier = tickCounter::get;
        this.checkManager = new CheckManager(this, config, dataManager, violations, tickSupplier);

        // PacketEvents settings (best-effort; ignore if the API differs).
        try {
            PacketEvents.getAPI().getSettings().checkForUpdates(false).reEncodeByDefault(false);
        } catch (Throwable ignored) { }
        PacketEvents.getAPI().init();
        PacketEvents.getAPI().getEventManager().registerListener(
                new PacketListener(this, dataManager, checkManager, config, tickSupplier));

        this.bukkitListener = new BukkitListener(this, dataManager, checkManager, violations, tickSupplier);
        getServer().getPluginManager().registerEvents(bukkitListener, this);

        // Tick counter: +1 every server tick.
        SchedulerUtil.runRepeatingGlobal(this, tickCounter::incrementAndGet, 1L, 1L);

        // VL decay on the configured interval.
        long interval = Math.max(1, config.violationTickInterval);
        SchedulerUtil.runRepeatingGlobal(this,
                () -> violations.decayTick(dataManager.all(), checkManager), interval, interval);

        // Periodically re-derive server-authoritative item + movement-state flags
        // (these aren't carried by the packets we parse).
        SchedulerUtil.runRepeatingGlobal(this, this::refreshAllStates, 20L, 20L);

        // Persist violations periodically (every ~60s) so a crash doesn't lose VL.
        if (config.saveViolations) {
            SchedulerUtil.runRepeatingGlobal(this,
                    () -> violations.saveAll(dataManager.all()), 1200L, 1200L);
        }

        // Adopt already-online players (e.g. after a /reload).
        long now = tickCounter.get();
        for (Player p : getServer().getOnlinePlayers()) {
            PlayerData data = dataManager.getOrCreate(p.getUniqueId(), p.getName());
            dataManager.linkEntityId(data, p.getEntityId());
            violations.restore(data);
            data.joinTick = now;
            data.lastTeleportTick = now;
            SchedulerUtil.runForEntity(this, p, () -> {
                bukkitListener.refreshHeldItem(p, data);
                bukkitListener.refreshState(p, data);
            });
        }

        getLogger().info("SentinelAC enabled (Folia mode: " + SchedulerUtil.isFolia() + ").");
    }

    @Override
    public void onDisable() {
        // Persist VL so it survives the restart.
        if (config != null && config.saveViolations && dataManager != null) {
            violations.saveAll(dataManager.all());
        }
        try {
            PacketEvents.getAPI().terminate();
        } catch (Throwable ignored) { }
        getLogger().info("SentinelAC disabled.");
    }

    private void refreshAllStates() {
        for (Player p : getServer().getOnlinePlayers()) {
            PlayerData data = dataManager.get(p.getUniqueId());
            if (data == null) continue;
            SchedulerUtil.runForEntity(this, p, () -> {
                bukkitListener.refreshHeldItem(p, data);
                bukkitListener.refreshState(p, data);
            });
        }
    }

    // -----------------------------------------------------------------------
    //  /sentinel command
    // -----------------------------------------------------------------------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("sentinel")) return false;

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "help" -> sendHelp(sender);
            case "reload" -> {
                config.reload();
                checkManager.reload();
                sender.sendMessage("§aSentinelAC config reloaded. "
                        + "§7(rotation sample-size changes need a restart)");
            }
            case "vl" -> {
                if (args.length < 2) {
                    sender.sendMessage("§cUsage: /sentinel vl <player>");
                    return true;
                }
                Player target = getServer().getPlayerExact(args[1]);
                PlayerData data = target != null ? dataManager.get(target.getUniqueId()) : null;
                if (data == null) {
                    sender.sendMessage("§cNo tracked data for '" + args[1] + "'.");
                    return true;
                }
                Map<String, Double> vls = data.getViolations();
                if (vls.isEmpty()) {
                    Map<String, String> recent = data.getRecentFlags(30_000L);
                    if (!recent.isEmpty()) {
                        sender.sendMessage(data.name + " has no active VL, but flagged recently:");
                        recent.forEach((check, reason) ->
                                sender.sendMessage("  " + check + " - " + reason));
                        return true;
                    }
                    sender.sendMessage("§a" + data.name + " has no active violations.");
                } else {
                    sender.sendMessage("§7Violations for §f" + data.name + "§7 (ping "
                            + data.pingMs + "ms):");
                    vls.forEach((check, vl) ->
                            sender.sendMessage(String.format("  §e%-16s §f%.1f", check, vl)));
                }
            }
            case "exempt" -> {
                if (args.length < 2) {
                    sender.sendMessage("§cUsage: /sentinel exempt <player>");
                    return true;
                }
                Player target = getServer().getPlayerExact(args[1]);
                java.util.UUID id;
                String shownName;
                if (target != null) { id = target.getUniqueId(); shownName = target.getName(); }
                else {
                    @SuppressWarnings("deprecation")
                    var off = getServer().getOfflinePlayer(args[1]);
                    if (off == null || off.getUniqueId() == null) {
                        sender.sendMessage("§cUnknown player '" + args[1] + "'.");
                        return true;
                    }
                    id = off.getUniqueId();
                    shownName = off.getName() != null ? off.getName() : args[1];
                }
                boolean nowExempt = violations.toggleExempt(id);
                // Mirror onto live data immediately if they're online.
                PlayerData d = dataManager.get(id);
                if (d != null) { d.manualExempt = nowExempt; d.exemptOverride = nowExempt; }
                sender.sendMessage(nowExempt
                        ? "§a" + shownName + " is now exempt from SentinelAC."
                        : "§7" + shownName + " is no longer exempt.");
            }
            case "alerts" -> {
                if (sender instanceof Player p) {
                    boolean on = violations.toggleAlerts(p.getUniqueId());
                    sender.sendMessage(on ? "§aAlerts enabled." : "§7Alerts muted.");
                } else {
                    sender.sendMessage("§7Console always receives alerts.");
                }
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender s) {
        s.sendMessage("§8§m                    §r §cSentinelAC §8§m                    ");
        s.sendMessage("§e/sentinel help §7- show this list");
        s.sendMessage("§e/sentinel reload §7- reload config.yml + all checks");
        s.sendMessage("§e/sentinel vl <player> §7- show a player's violation levels");
        s.sendMessage("§e/sentinel exempt <player> §7- toggle a player's exemption");
        s.sendMessage("§e/sentinel alerts §7- toggle your own flag alerts");
        s.sendMessage("§7Always exempt: §fOP, anticheat.bypass perm, /exempt'd players.");
    }
}
